#########################################################################################
##
## Author - Akshay Agarwal
##
## Module goal - This is the main module of this search application which takes two user inputs:
##               search term - the term user is searching in the data files
##               search method - the method to be used for the search operation with
##               following 3 permissible values:
##                        1. simple_search
##                        2. regex_search
##                        3. index_search
##               dictionary of source files names as key and corresponding file data
##               as value.
##
## Output -      This module prints the file name and the count of occurence of the searched term
##               in descending order of relevance, with the file containing the highest count of searched
##               term displayed on top in the output followed by the files with lower count of searched
##               word in descending order.
##
#########################################################################################


import os
import logging
from pathlib import Path
import json
import glob
from main import regex_search,index_search,simple_search
from main.utils import custom_error,get_source_data_folder,generate_dict_from_file_list


def main():
    try:
        search_word=input("Please enter the search term: ")
        search_method=input("Please enter the search method: ")
        # config_file_path=Path()
        root_dir=Path('')
        src_data_folder=get_source_data_folder.get_source_data_path(root_dir)

        search_text_file_names_list= [f for f in os.listdir(src_data_folder) if f.endswith('.txt')]

        search_files_list = glob.glob(str(src_data_folder)+'/*.txt')


        if (search_method == 'simple_search'):

            file_name_data_dict=generate_dict_from_file_list.get_dict_from_file_list(search_files_list)
            search_word_count_dict = simple_search.simple_search_word(search_word, file_name_data_dict)


        elif(search_method=='regex_search'):
            file_name_data_dict={}
            for file in search_files_list:
                try:
                    with open(file, 'r') as searchfile:

                        file_name_data_dict[file]=searchfile.read()

                except IOError:
                    print("File not found or path is incorrect")

            search_word_count_dict=regex_search.regex_search_word(search_word,file_name_data_dict)

        elif(search_method=='index_search'):
            preprocessed_file = glob.glob(str(src_data_folder) + '/*.json').pop()
            with open(preprocessed_file, 'r') as fwc:
                files_word_counts = json.load(fwc)

            search_word_count_dict=index_search.index_search_word(search_word,search_text_file_names_list,files_word_counts)

        else:
            logging.error("Please enter a valid search method name. Valid method names are -> 'simple_search' OR 'regex_search' OR index_search")
            raise custom_error.InvalidInputSearchMethodError

        for k, v in sorted(search_word_count_dict.items(), key=lambda x: x[1], reverse=True):
            print("Number of matches of word '{}' in {} - {}".format(search_word, k, v))


    except Exception as e:
        logging.exception(e)
        print(e)
        exit(1)


if __name__ == "__main__":
    main()

        # method_name = search_method
        #
        # module = importlib.import_module(method_name)
        # process_class = getattr(module, class_name)

        #
        # parser = argparse.ArgumentParser()
        # parser.add_argument("--file_name", help="enter the pyspark script to execute")
        #
        # parser.add_argument("--files", help="enter the configuration file")
        # # parser.add_argument("--home_dir", help="enter the home directory location")
        #
        # args = parser.parse_args()
        # file_name = args.file_name
        #
        # conf_file = args.files
