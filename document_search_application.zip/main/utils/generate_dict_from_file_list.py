#########################################################################################
##
## Author - Akshay Agarwal
##
## Module goal - This util function takes a list of files path as input and converts it
##               into a dictionary of file name as key and corresponding file data as value.
##
## Return type - Returns a dictionary with filename as key and file data as value
##
#########################################################################################


import re
def get_dict_from_file_list(search_files_list:list)->dict:
    file_name_data_dict={}
    for file in search_files_list:
        try:
            with open(file, 'r') as searchfile:

                file_name_data_dict[file] = re.split(r'[^a-zA-Z0-9_.-]', searchfile.read())

        except IOError:
            print("File not found or path is incorrect")
            exit(1)

    return file_name_data_dict