class Error(Exception):
   """Base class for other exceptions"""
   pass
class InvalidInputSearchMethodError(Error):
   """Raised when the input search method has invalid value"""
   pass