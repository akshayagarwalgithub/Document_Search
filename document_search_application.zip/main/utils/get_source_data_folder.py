#########################################################################################
##
## Author - Akshay Agarwal
##
## Module goal - This util function takes the root path as input and by reading the conf file
##               returns the path of the source files.
##
#########################################################################################


from pathlib import Path
import json
def get_source_data_path(root_dir:Path)->Path:
    with open(root_dir / 'conf' / 'config.json') as json_conf_file:
        #print("config file full path = {}".format(json_conf_file))
        conf_variables = json.load(json_conf_file)

    src_files_path = conf_variables['src_files_base_path']['path']
    src_data_folder = Path(src_files_path)
    return src_data_folder
