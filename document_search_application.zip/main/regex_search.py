#########################################################################################
##
## Author - Akshay Agarwal
##
## Module goal - This function regex_search_word takes in the input search_word,
##               dictionary of source files names as key and corresponding file data
##               as value. This function applies a regex search for the input search word
##               with the specified allowed pattern.
##
## Return type - Returns a dictionary with filename as key and the count of searched word
##               as value
#########################################################################################

import re
import os
import logging
file_search_word_count_dict={}
def regex_search_word(search_word:str,file_name_data_dict:dict)->dict:

    for file,data in file_name_data_dict.items():
        try:

            count_of_words = len(re.findall('[^A-Za-z0-9_.-]' + search_word + '[^A-Za-z0-9_.-]', data))
            head, tail = os.path.split(file)
            file_search_word_count_dict[tail] = count_of_words
        except Exception as e:
            logging.exception(e)
            print(e)
            exit(1)


    return file_search_word_count_dict

