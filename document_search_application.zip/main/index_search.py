#########################################################################################
##
## Author - Akshay Agarwal
##
## Module goal - This function index_search_word takes in the input search_word,
##               list of files to search and the preprocessed json data consisting
##               of word counts for input data files.
## Return type - Returns a dictionary with filename as key and the count of searched word
##               as value
#########################################################################################
import json
import logging
file_search_word_count_dict={}

def index_search_word(search_word:str,search_files_list:list,files_word_counts:json)->dict:

    for file in search_files_list:
        try:
            if search_word not in files_word_counts[file]:
                count_of_words=0
            else:
                count_of_words=files_word_counts[file][search_word]

            file_search_word_count_dict[file] = count_of_words
        except Exception as e:
            logging.exception(e)
            print(e)
            exit(1)


    return file_search_word_count_dict
