#########################################################################################
##
## Author - Akshay Agarwal
##
## Module goal - This module reads the source files and generates a json file containing the
##               count of respective words in each file
##
##
#########################################################################################


import json
from pathlib import Path
import glob
import os
from main.utils import get_source_data_folder,generate_dict_from_file_list

root_dir = Path(__file__).parent.parent.parent
print("Root directory path is {}".format(str(root_dir)))
src_data_folder= get_source_data_folder.get_source_data_path(root_dir)

print("src_data_folder={}".format(src_data_folder))

search_files_list = glob.glob(str(root_dir)+str(Path('/'))+str(src_data_folder) + '/*.txt')
print(search_files_list)

file_name_data_dict=generate_dict_from_file_list.get_dict_from_file_list(search_files_list)


def load_word_counts_files_into_dict(file_name_data_dict:dict)->dict:
    word_count_dict = {}
#Problematic area where I had to initilise the dictionary with a particular key as NoneType is not iterable and subsriptable
    for file,data in file_name_data_dict.items():
        head, tail = os.path.split(file)
        word_count_dict[tail]={'':1}

        for word in data:
            if word not in word_count_dict[tail]:
                word_count_dict[tail][word]=1
            else:
                word_count_dict[tail][word]+=1

    return word_count_dict

with open('files_word_count.json', 'w') as fwc:
    json.dump(load_word_counts_files_into_dict(file_name_data_dict),fwc)


