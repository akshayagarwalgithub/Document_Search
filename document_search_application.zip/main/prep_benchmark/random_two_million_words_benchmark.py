#########################################################################################
##
## Author - Akshay Agarwal
##
## Module goal - This module performs the benchmarking on 2 Million random search words and prints
##               the time elapsed by each type of search method. This benchmarking calculates the
##               time elapsed by each search method in returning the dictionary of counts of searched
##               word in each file,sorted in descending order of search occurence in the files,
##               when sequentially executed for 2 Million words.
##
#########################################################################################

from main import regex_search,index_search,simple_search
import random
import re
import time
from pathlib import Path
import json
import os
import glob
from main.utils import get_source_data_folder,generate_dict_from_file_list

random_word_list=[]
root_dir = Path(__file__).parent.parent.parent
#print("Root directory path is {}".format(str(root_dir)))

src_data_folder=get_source_data_folder.get_source_data_path(root_dir)

search_text_file_names_list = [f for f in os.listdir(root_dir/src_data_folder) if f.endswith('.txt')]

search_files_list = glob.glob(str(root_dir)+str(Path('/'))+str(src_data_folder) + '/*.txt')

preprocessed_file = glob.glob(str(root_dir)+str(Path('/'))+str(src_data_folder) + '/*.json').pop()

with open(preprocessed_file, 'r') as fwc:
    files_word_counts = json.load(fwc)

file_name_data_dict_simple_search={}

start_time_simple_search_dict_prep = time.time()
print("start time for prep simple search = {}".format(start_time_simple_search_dict_prep))

file_name_data_dict_simple_search=generate_dict_from_file_list.get_dict_from_file_list(search_files_list)

elapsed_time_simple_search_prep = (time.time() - start_time_simple_search_dict_prep)
print("elapsed time for prep simple search = {} \n".format(elapsed_time_simple_search_prep))

start_time_regex_search_dict_prep = time.time()
print("start time for prep regex search = {}".format(start_time_regex_search_dict_prep))

file_name_data_dict_regex_search={}

for file in search_files_list:
    try:
        with open(file, 'r') as searchfile:

            file_name_data_dict_regex_search[file] = searchfile.read()

    except IOError:
        print("File not found or path is incorrect")

elapsed_time_regex_search_prep = (time.time() - start_time_regex_search_dict_prep)
print("elapsed time for prep regex search = {} \n".format(elapsed_time_regex_search_prep))


file_for_random_word=search_files_list[1]
print(file_for_random_word)

for num in range(2000000):

    random_word=random.choice(re.split(r'[^a-zA-Z0-9_.-]',open(file_for_random_word).read()))
    random_word_list.append(random_word)

start_time_simple_search = time.time()
print("start time for simple search = {}".format(start_time_simple_search))

for random_word in random_word_list:

#simple_search method call
    search_word_count_dict=simple_search.simple_search_word(random_word,file_name_data_dict_simple_search)
    result_dict= sorted(search_word_count_dict.items(), key=lambda x: x[1], reverse=True)
    #print("simple_search_result_dict={}".format(result_dict))

elapsed_time_simple_search = (time.time() - start_time_simple_search)
print("elapsed time for simple search = {} \n".format(elapsed_time_simple_search))

start_time_regex = time.time()
print("start time for regex search = {}".format(start_time_regex))

for random_word in random_word_list:

    #regex_search method call
    search_word_count_dict=regex_search.regex_search_word(random_word,file_name_data_dict_regex_search)
    result_dict = sorted(search_word_count_dict.items(), key=lambda x: x[1], reverse=True)
    #print("regex_search_result_dict={}".format(result_dict))
elapsed_time_regex = (time.time() - start_time_regex)
print("elapsed time for regex search = {} \n".format(elapsed_time_regex))

start_time_index = time.time()
print("start time for index search = {}".format(start_time_index))

for random_word in random_word_list:

    # index_search method call
    search_word_count_dict=index_search.index_search_word(random_word, search_text_file_names_list, files_word_counts)
    result_dict= sorted(search_word_count_dict.items(), key=lambda x: x[1], reverse=True)
    #print("index_search_result_dict={}".format(result_dict))
elapsed_time_index = (time.time() - start_time_index)
print("elapsed time for index search = {}".format(elapsed_time_index))