#########################################################################################
##
## Author - Akshay Agarwal
##
## Module goal - This function simple_search_word takes in the input search_word,
##               dictionary of source files names as key and corresponding file data
##               as value.
##
## Return type - Returns a dictionary with filename as key and the count of searched word
##               as value
#########################################################################################

import os
import logging
file_search_word_count_dict={}
def simple_search_word(search_word:str,file_name_data_dict:dict)->dict:
    for file,data in file_name_data_dict.items():
        try:
            count_of_words = 0
            for word in data:
                if search_word == word:
                    count_of_words += 1

            head, tail = os.path.split(file)

            file_search_word_count_dict[tail] = count_of_words
        except Exception as e:
            logging.exception(e)
            print(e)
            exit(1)


    return file_search_word_count_dict


